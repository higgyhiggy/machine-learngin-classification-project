The test accuracies and training times for the above three classificatoins are:

classification #1
test accuracy: 0.9761
time to run: 2 min 48 seconds
epoch: 12

classification #2
test accuracy: 0.9793
time to run: 2 min 48 seconds
epoch: 4

classification #3
test accuracy: 0.9798
time to run: 2 min 48 seconds
epoch: 4



